import React from "react";

type StatItem = {
  value: string;
  label: string;
};

const stats: StatItem[] = [
  { value: "1k+", label: "Orders delivered" },
  { value: "4.8★", label: "Avg customer rating" },
  { value: "7-10 Days", label: "Typical delivery time" },
];

const UserRating: React.FC = () => {
  return (
    <div className="lg:hidden flex mb-4  justify-around items-center bg-white dark:bg-gray-900 p-6 rounded-xl border border-neutral-200 shadow gap-4 max-w-[700px]">
      {stats.map((stat, index) => (
        <div key={index} className="flex flex-col items-center text-center">
          <span className="text-lg md:text-2xl font-bold text-themeBlue dark:text-blue-400">
            {stat.value}
          </span>
          <span className="text-[12px] sm:text-xs md:text-sm text-gray-600 dark:text-gray-300">
            {stat.label}
          </span>
        </div>
      ))}
    </div>
  );
};

export default UserRating;
